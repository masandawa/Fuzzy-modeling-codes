function Z = fmh_design(N, nf, al)
%FMH_DESIGN Sampling design on the unit box for one alpha-cut: about 75% random
%   vertices, the rest Latin-hypercube interior points, plus the centre (N points).
if al == 1, Z = 0.5*ones(1, nf); return; end
nc = round(0.755*(N - 1)); ni = N - 1 - nc;
Zc = double(rand(nc, nf) > 0.5);
Zi = zeros(ni, nf);
for j = 1:nf, Zi(:,j) = (randperm(ni)' - rand(ni,1))/ni; end
Z = [Zc; Zi; 0.5*ones(1, nf)];
end
