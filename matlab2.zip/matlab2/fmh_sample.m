function [pp, tg] = fmh_sample(p0, FIN, fn, al, z)
%FMH_SAMPLE Parameter set and calibration targets at unit-box point z of the alpha-cut.
pp = p0; tg = zeros(1,3);
for j = 1:numel(fn)
    I = fmh_alphacut(FIN.(fn{j}), al);
    if al == 1, v = FIN.(fn{j})(2); else, v = I(1) + z(j)*(I(2) - I(1)); end
    switch fn{j}
        case 'dur', pp.gw0 = 1/(v*365);
        case 'Pm',  tg(1) = v;
        case 'Pw',  tg(2) = v;
        case 'OR',  tg(3) = v;
        otherwise,  pp.(fn{j}) = v;
    end
end
end
