function o = fmh_summaries(y, p, d)
%FMH_SUMMARIES Epidemiological outputs of a state (or matrix of states, one per column).
s0 = y(1,:); i0 = y(3,:); s1 = y(5,:); i1 = y(7,:); iv = y(12,:);
h = sum(y(5:8,:), 1);
lam_m = p.a*(1-p.u)*p.b*p.mv*iv;
o.Pm  = i0 + i1;                 % malaria prevalence (infectious, mRDT-positive)
o.Pw  = h;                       % hookworm prevalence
o.Pc  = i1;                      % malaria-hookworm co-infection prevalence
o.OR  = (i1.*(1 - h - i0))./((h - i1).*i0);   % odds ratio of malaria given hookworm
o.inc = 1000*365*lam_m.*(s0 + d.th*s1);       % malaria infections per 1000 person-years
o.R   = y(4,:) + y(8,:);         % temporarily immune
end
