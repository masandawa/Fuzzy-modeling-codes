function [q, y, res] = fmh_calibrate(p, targets, ~)
%FMH_CALIBRATE Exact (closed-form) calibration of mv, pimax and thetaM.
%   targets = [malaria prevalence Pm, hookworm prevalence Pw, odds ratio OR].
%   The co-existence equilibrium of the averaged model is reconstructed analytically
%   (Section 5.2 of the manuscript):
%   (1) i0, i1 from Pm, Pw and OR (quadratic);
%   (2) lambda_W = (gw+mu)Pw/(1-Pw) from the exact hookworm balance, then L and pi(eps);
%   (3) r0, r1 and e0, e1 from the r- and i-equations (linear);
%   (4) s0, s1 by conservation; lambda_M from the e0-equation; theta(eps) from the e1-equation;
%   (5) mosquito equilibrium from lambda_V, then mv = lambda_M/(a(1-u) b iv).
%   res = [Pm error, Pw error, log OR error, max|rhs|]; NaN flags infeasible targets.
Pm = targets(1); h = targets(2); OR = targets(3);
q = p; q.mv = 1; q.pimax = 1; q.thetaM = 1;
d = fmh_derived(q);
mu = p.mu; gw = d.gw; gm = d.gm; z = p.zeta; nh = p.nuh; ps = p.psi;
% (1) infectious proportions in the two hookworm strata
A2 = 1 - OR; A1 = (1 - h - Pm) + OR*(h + Pm); A0 = -OR*h*Pm;
if abs(A2) < 1e-12
    i1 = -A0/A1;
else
    rts = roots([A2 A1 A0]); rts = real(rts(abs(imag(rts)) < 1e-12));
    rts = rts(rts > 0 & rts < min(h, Pm)); i1 = rts(1);
end
i0 = Pm - i1;
% (2) hookworm
lamW = (gw + mu)*h/(1 - h);
L = lamW/(p.beta_w - lamW);
pieps = p.muL*L/((1 - p.wash)*h);
q.pimax = pieps/fmh_shape(q, q.eps, q.rho);
% (3) recovered and exposed
R = [ps + lamW + mu, -gw; -lamW, ps + gw + mu] \ [gm*i0; z*gm*i1];
r0 = R(1); r1 = R(2);
e0 = ((gm + lamW + mu)*i0 - gw*i1)/nh;
e1 = ((z*gm + gw + mu)*i1 - lamW*i0)/nh;
% (4) susceptibles, malaria force of infection and interaction modifier
s0 = (1 - h) - e0 - i0 - r0; s1 = h - e1 - i1 - r1;
lamM = ((nh + lamW + mu)*e0 - gw*e1)/s0;
th = ((nh + gw + mu)*e1 - lamW*e0)/(lamM*s1);
if isfield(q,'shape_eps'), kk = q.shape_eps; else, kk = 'linear'; end
fr = fmh_resp(q.eps/q.eps_M, kk);
q.thetaM = q.theta0 + (th - q.theta0)/fr;
% (5) mosquitoes
lamV = p.a*(1 - p.u)*d.cr*(i0 + p.eta*i1);
sv = p.muv/(lamV + p.muv); ev = lamV*sv/(p.nuv + p.muv); iv = p.nuv*ev/p.muv;
q.mv = lamM/(p.a*(1 - p.u)*p.b*iv);
y = [s0; e0; i0; r0; s1; e1; i1; r1; L; sv; ev; iv];
d = fmh_derived(q);
o = fmh_summaries(y, q, d);
res = [o.Pm - Pm, o.Pw - h, log(o.OR) - log(OR), max(abs(fmh_rhs(0, y, q, d)))];
if p.beta_w <= lamW || lamM <= 0 || th <= 0 || any(y < 0), res(1:3) = NaN; end
end
