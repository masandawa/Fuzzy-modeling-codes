% Convergence of scenario outcomes (B, D2, M, I1) and periodic-baseline check.
% Usage: set N and alv before running, e.g. octave --eval "N=200; alv=[0 .25 .5 .75]; run conv_scen.m"
addpath('/home/claude/matlab2'); outdir = '/home/claude/matlab2/results';
p0 = fmh_params(); [FIN, fn] = fmh_fuzzyinputs(); nf = numel(fn);

vd = dlmread(fullfile(outdir,'hindcast_summary.csv'), ',', 1, 0); umax = vd(1);
S = struct('name',{'B','D2','M','I1'},'kind',{'annual','semi','annual','semi'}, ...
           'phi',{0.225,0.75,0.225,0.75},'u',{0,0,umax,umax});
OUT = [];
for al = alv
  rng(1000*N + round(100*al));
  Z = fmh_design(N, nf, al);
  for n = 1:size(Z,1)
    [pp, tg] = fmh_sample(p0, FIN, fn, al, Z(n,:));
    [qs, ys, rs] = fmh_calibrate(pp, tg);
    if any(isnan(rs)) || max(abs(rs(1:3))) > 1e-6, continue; end
    [tb, Yb] = fmh_simulate(qs, ys, [0 8*365], fmh_schedule('annual', qs.phi, 0, 8*365), 5);
    y0 = Yb(:, end); y7 = Yb(:, abs(tb - 7*365) < 1e-9);
    per = max(abs(y0 - y7)./max(abs(y0), 1e-6));      % stroboscopic change, year 7 -> 8
    row = [N, al, n, Z(n,:), per];
    for sI = 1:numel(S)
      [~, Y1] = fmh_simulate(qs, y0, [0 365], fmh_schedule('annual', qs.phi, 0, 365), 5);
      q2 = qs; q2.u = S(sI).u;
      [~, Y2] = fmh_simulate(q2, Y1(:,end), [365 5*365], fmh_schedule(S(sI).kind, S(sI).phi, 365, 5*365), 5);
      d1 = fmh_derived(qs, [], [], false); o1 = fmh_summaries(Y1, qs, d1);
      d2 = fmh_derived(q2, [], [], false); o2 = fmh_summaries(Y2(:,2:end), q2, d2);
      inc = [o1.inc o2.inc]; Pw = [o1.Pw o2.Pw];
      MHI = fmh_mhi(Pw, qs, qs.eps, tg(2));
      nt = numel(inc); tg5 = (0:nt-1)*5;
      red = 100*(1 - mean(inc(tg5 >= 4*365))/mean(inc(tg5 < 365)));
      row = [row, red, 100*mean(MHI(tg5 >= 4*365))]; %#ok<AGROW>
    end
    OUT = [OUT; row]; %#ok<AGROW>
  end
  fprintf('N=%d alpha=%.2f done\n', N, al); fflush(stdout);
end
tag = sprintf('%d_%s', N, strrep(num2str(alv), ' ', ''));
fmh_writecsv(fullfile(outdir, ['conv_scen_' tag '.csv']), ...
  ['N,alpha,n,' strjoin(fn',',') ',per,red_B,MHI_B,red_D2,MHI_D2,red_M,MHI_M,red_I1,MHI_I1'], OUT);
