% Convergence of alpha-cut bounds of calibration-derived quantities (N = 53,200,500,1000)
% plus optimisation-based extrema (multistart Nelder-Mead on the alpha-cut box).
addpath('/home/claude/matlab2'); outdir = '/home/claude/matlab2/results';
p0 = fmh_params(); [FIN, fn] = fmh_fuzzyinputs(); nf = numel(fn);
alv = [0 0.25 0.5 0.75]; Ns = [53 200 500 1000];
OUT = [];
for N = Ns
  rng(100 + N);
  for al = alv
    Z = fmh_design(N, nf, al);
    for n = 1:size(Z,1)
      [pp, tg] = fmh_sample(p0, FIN, fn, al, Z(n,:));
      [qs, ys, rs] = fmh_calibrate(pp, tg);
      if any(isnan(rs)) || max(abs(rs(1:3))) > 1e-6, continue; end
      ds = fmh_derived(qs); [RMs, RWs] = fmh_R0(qs, ds); [Phis, RMWs] = fmh_invasion(qs, ds);
      OUT = [OUT; N, al, n, Z(n,:), ds.th, Phis, RMs, RWs, RMWs, qs.mv]; %#ok<AGROW>
    end
  end
  fprintf('N=%d done\n', N);
end
fmh_writecsv(fullfile(outdir,'conv_static.csv'), ['N,alpha,n,' strjoin(fn',',') ',theta_eps,Phi,RM,RW,RMW,mv'], OUT);
% optimisation-based extrema of theta(eps), Phi
f = @(z, al, k) fmh_static_out(p0, FIN, fn, al, z, k);
OPT = [];
for al = alv
  for k = 1:2
    for sgn = [1 -1]
      best = Inf;
      for st = 1:12
        x0 = randn(1, nf);
        obj = @(x) sgn*f((sin(x)+1)/2, al, k);
        [x, fv] = fminsearch(obj, x0, optimset('MaxFunEvals', 1500, 'Display', 'off'));
        best = min(best, fv);
      end
      OPT = [OPT; al, k, sgn, sgn*best]; %#ok<AGROW>
    end
  end
end
fmh_writecsv(fullfile(outdir,'conv_static_opt.csv'), 'alpha,qty,sign,value', OPT);
