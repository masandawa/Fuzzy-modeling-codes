% Structural sensitivity: principal results under three intensity-response forms.
addpath('/home/claude/matlab2'); outdir = '/home/claude/matlab2/results';
vd = dlmread(fullfile(outdir,'hindcast_summary.csv'), ',', 1, 0); umax = vd(1);
V = {'linear','linear'; 'concave','linear'; 'sigmoid','linear'; 'linear','concave'; 'linear','sigmoid'}; tgt = [0.223 0.187 1.32];
Hgrp = [24 1000 3000; 1000 3000 5000; 3000 5000 8000];
Mgrp = [1 2.5 3.5; 2.5 3.5 4.5; 3.5 4.5 5];
eg = linspace(0, 10000, 5001); rg = unique([linspace(0, 2000, 2001), linspace(2000, 100000, 9801)]);
lrg = log10(max(rg, 1e-9));
S = struct('kind',{'annual','semi','annual','semi'},'phi',{0.225,0.75,0.225,0.75},'u',{0,0,umax,umax});
OUT = [];
for k = 1:size(V,1)
  p0 = fmh_params(); p0.shape_eps = V{k,1}; p0.shape_rho = V{k,2};
  [q, ys, rs] = fmh_calibrate(p0, tgt); d = fmh_derived(q);
  if any(isnan(rs)) || q.mv <= 0 || q.thetaM <= 0, fprintf('variant %d infeasible\n', k); OUT = [OUT; k, nan(1,27)]; continue; end
  [RM, RW] = fmh_R0(q, d); [Phi, RMW] = fmh_invasion(q, d);
  o = fmh_summaries(ys, q, d);
  q0 = q; q0.pimax = 0; d0 = fmh_derived(q0); [~, ~, yM] = fmh_boundary(q0, d0); o0 = fmh_summaries(yM, q0, d0);
  attr = 100*(o.inc - o0.inc)/o.inc;
  RWg = zeros(size(eg)); PhiG = RWg; PHa = RWg; PHs = RWg; RMg = zeros(size(rg));
  for j = 1:numel(eg)
    dk = fmh_derived(q, eg(j), q.rho); [~, RWg(j)] = fmh_R0(q, dk); PhiG(j) = fmh_invasion(q, dk);
  end
  for j = 1:numel(rg), dk = fmh_derived(q, q.eps, rg(j)); RMg(j) = fmh_R0(q, dk); end
  ec = 0:25:4000; pa = zeros(size(ec)); ps = pa;
  for j = 1:numel(ec)
    dk = fmh_derived(q, ec(j), q.rho); pa(j) = fmh_critcov_imp(q, dk, 365); ps(j) = fmh_critcov_imp(q, dk, 182.5);
  end
  pa(isinf(pa)) = 2; ps(isinf(ps)) = 2;
  ja = find(pa >= 0.75, 1); js = find(ps >= 0.75, 1);
  e75a = interp1(pa(ja-1:ja), ec(ja-1:ja), 0.75); e75s = interp1(ps(js-1:js), ec(js-1:js), 0.75);
  epsRW1 = eg(find(RWg >= 1, 1));
  G = fmh_trimf(eg, Hgrp(1,:)); RWf = max(RWg)*fmh_fev(RWg/max(RWg), G);
  PossEl = max([0, G(RWg < 1)]); NecFac = 1 - max([0, G(PhiG <= 1)]);
  RWmod = interp1(eg, RWg, 1000);
  G = fmh_trimf(lrg, Mgrp(1,:)); RMf = max(RMg)*fmh_fev(RMg/max(RMg), G); RMmod = interp1(rg, RMg, 10^2.5);
  % scenarios at the core
  [~, Yb] = fmh_simulate(q, ys, [0 8*365], fmh_schedule('annual', q.phi, 0, 8*365), 5); y0 = Yb(:,end);
  red = zeros(1,4); MH = red;
  for sI = 1:4
    [~, Y1] = fmh_simulate(q, y0, [0 365], fmh_schedule('annual', q.phi, 0, 365), 5);
    q2 = q; q2.u = S(sI).u;
    [~, Y2] = fmh_simulate(q2, Y1(:,end), [365 5*365], fmh_schedule(S(sI).kind, S(sI).phi, 365, 5*365), 5);
    o1 = fmh_summaries(Y1, q, fmh_derived(q,[],[],false)); o2 = fmh_summaries(Y2(:,2:end), q2, fmh_derived(q2,[],[],false));
    inc = [o1.inc o2.inc]; Pw = [o1.Pw o2.Pw]; tg5 = (0:numel(inc)-1)*5;
    red(sI) = 100*(1 - mean(inc(tg5 >= 4*365))/mean(inc(tg5 < 365)));
    MH(sI) = 100*mean(fmh_mhi(Pw(tg5 >= 4*365), q, q.eps, tgt(2)));
  end
  bliss = red(4) - 100*(1 - (1 - red(3)/100)*(1 - red(2)/100));
  OUT = [OUT; k, q.mv, RM, RW, Phi, RMW, 1/sqrt(Phi), attr, epsRW1, interp1(eg,PhiG,1000), ...
         pa(ec==600), ps(ec==600), e75a, e75s, RWmod, RWf, PossEl, NecFac, RMmod, RMf, max(RMg), ...
         red, bliss, MH(1), MH(2)]; %#ok<AGROW>
  fprintf('variant %d done\n', k);
end
fmh_writecsv(fullfile(outdir,'structural_sensitivity.csv'), ...
 ['shape,mv,RM,RW,Phi,RMW,RM_thr,attr_inc,eps_RW1,Phi1000,phic_ann600,phic_semi600,eps75_ann,eps75_semi,' ...
  'RW_modal_light,RWf_light,PossElim_light,NecFacil_light,RM_modal_low,RMf_low,RM_peak,red_B,red_D2,red_M,red_I1,bliss,MHI_B,MHI_D2'], OUT);
