% Structural sensitivity of the uncertainty results: Nec(Phi>1), Poss(theta<1) under fuzzy
% targets (200 points per alpha) and the identifiability grid, for each response form.
addpath('/home/claude/matlab2'); outdir = '/home/claude/matlab2/results';
V = {'linear','linear'; 'concave','linear'; 'sigmoid','linear'; 'linear','sigmoid'};
[FIN, fn] = fmh_fuzzyinputs(); nf = numel(fn); alv = [0 0.25 0.5 0.75];
OUT = []; IDS = [];
for k = 1:size(V,1)
  p0 = fmh_params(); p0.shape_eps = V{k,1}; p0.shape_rho = V{k,2};
  rng(55);
  for al = alv
    Z = fmh_design(200, nf, al);
    for n = 1:size(Z,1)
      [pp, tg] = fmh_sample(p0, FIN, fn, al, Z(n,:));
      [qs, ~, rs] = fmh_calibrate(pp, tg);
      if any(isnan(rs)) || max(abs(rs(1:3))) > 1e-6 || qs.mv <= 0, continue; end
      ds = fmh_derived(qs); OUT = [OUT; k, al, ds.th, fmh_invasion(qs, ds)]; %#ok<AGROW>
    end
  end
  for t0 = [0.8 0.95 1.0], for et = linspace(1,1.3,7), for ze = linspace(0.7,1,7)
    pp = p0; pp.eta = et; pp.zeta = ze; pp.theta0 = t0;
    [qs, ys, rs] = fmh_calibrate(pp, [0.223 0.187 1.32]);
    if any(isnan(rs)) || qs.mv <= 0, continue; end
    ds = fmh_derived(qs); os = fmh_summaries(ys, qs, ds); Phis = fmh_invasion(qs, ds);
    q0 = qs; q0.pimax = 0; d0 = fmh_derived(q0); [~, ~, yM] = fmh_boundary(q0, d0); o0 = fmh_summaries(yM, q0, d0);
    IDS = [IDS; k, Phis, 100*(os.inc - o0.inc)/os.inc]; %#ok<AGROW>
  end, end, end
  fprintf('variant %d\n', k);
end
fmh_writecsv(fullfile(outdir,'structural_fuzzy.csv'), 'variant,alpha,theta_eps,Phi', OUT);
fmh_writecsv(fullfile(outdir,'structural_ident.csv'), 'variant,Phi,attr_inc', IDS);
