function [hs, Ls, yM, yW] = fmh_boundary(p, d)
%FMH_BOUNDARY Explicit boundary equilibria (Theorems 4 and 5).
%   hs, Ls : hookworm prevalence and larvae at the hookworm-only equilibrium E_W
%   yM     : full state at the malaria-only equilibrium E_M (zeros if R_M <= 1)
%   yW     : full state at E_W
[RM, RW] = fmh_R0(p, d);
k  = (1-p.wash)*d.pi/p.muL;
hs = max(0, (RW - 1)/(RW + k));
Ls = k*hs;
yW = [1-hs; 0; 0; 0; hs; 0; 0; 0; Ls; 1; 0; 0];
A  = p.a*(1-p.u)*p.b*p.mv*p.nuv/(p.nuv + p.muv);
B  = p.a*(1-p.u)*d.cr;
G  = (p.nuh + p.mu)*(d.gm + p.mu)/p.nuh;
K  = 1 + (d.gm + p.mu)/p.nuh + d.gm/(p.psi + p.mu);
if RM > 1
    is = (A*B - G*p.muv)/(B*(A*K + G));
else
    is = 0;
end
es = (d.gm + p.mu)*is/p.nuh; rs = d.gm*is/(p.psi + p.mu); ss = 1 - es - is - rs;
lv = B*is; svs = p.muv/(lv + p.muv); evs = lv*svs/(p.nuv + p.muv); ivs = p.nuv*evs/p.muv;
yM = [ss; es; is; rs; 0; 0; 0; 0; 0; svs; evs; ivs];
end
