function y = fmh_ic(v)
%FMH_IC Interior initial condition (default) or user vector of 12 states normalised.
if nargin < 1
    y = [0.50 0.04 0.12 0.10 0.10 0.02 0.06 0.06 0.10 0.85 0.07 0.08]';
else
    y = v(:);
end
y(1:8) = y(1:8)/sum(y(1:8)); y(10:12) = y(10:12)/sum(y(10:12));
end
