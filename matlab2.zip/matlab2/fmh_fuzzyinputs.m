function [FIN, fn] = fmh_fuzzyinputs()
%FMH_FUZZYINPUTS Triangular fuzzy numbers of the nine uncertain inputs.
FIN = struct('theta0',[0.80 0.95 1.00],'eta',[1.00 1.11 1.30],'zeta',[0.70 0.85 1.00], ...
             'CR',[0.50 0.72 0.81],'dur',[1 2 3],'eps',[200 600 1500], ...
             'Pm',[0.216 0.223 0.229],'Pw',[0.062 0.187 0.380],'OR',[0.98 1.32 1.78]);
fn = fieldnames(FIN);
end
