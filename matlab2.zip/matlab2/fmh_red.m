function f = fmh_red(x, p, d)
%FMH_RED Reduced vector field in x = y([2:9 11 12]).
y = [1 - sum(x(1:7)); x(1:8); 1 - x(9) - x(10); x(9:10)];
F = fmh_rhs(0, y, p, d);
f = F([2:9 11 12]);
end
