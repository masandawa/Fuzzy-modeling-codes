function mda = fmh_schedule(kind, phi, t0, t1)
%FMH_SCHEDULE Deworming times in [t0,t1): 'annual' (mid-year) or 'semi' (twice yearly).
y0 = floor(t0/365); y1 = ceil(t1/365);
switch kind
    case 'annual', off = 180;
    case 'semi',   off = [90 270];
    otherwise,     off = [];
end
t = [];
for k = y0:y1
    t = [t, 365*k + off]; %#ok<AGROW>
end
t = t(t >= t0 & t < t1);
mda = [t(:), phi*ones(numel(t),1)];
end
