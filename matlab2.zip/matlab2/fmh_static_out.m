function v = fmh_static_out(p0, FIN, fn, al, z, k)
%FMH_STATIC_OUT theta(eps) (k=1) or Phi (k=2) after calibration at box point z.
[pp, tg] = fmh_sample(p0, FIN, fn, al, z);
[qs, ~, rs] = fmh_calibrate(pp, tg);
if any(isnan(rs)) || max(abs(rs(1:3))) > 1e-6, v = NaN; return; end
ds = fmh_derived(qs);
if k == 1, v = ds.th; else, v = fmh_invasion(qs, ds); end
end
