function r = fmh_prcc(X, y)
%FMH_PRCC Partial rank correlation coefficients of output y with columns of X.
n = size(X,1); k = size(X,2);
R = zeros(n,k);
for j = 1:k, [~, ix] = sort(X(:,j)); R(ix,j) = (1:n)'; end
[~, iy] = sort(y); ry = zeros(n,1); ry(iy) = (1:n)';
r = zeros(1,k);
for j = 1:k
    Z = [ones(n,1), R(:, setdiff(1:k, j))];
    ex = R(:,j) - Z*(Z\R(:,j));
    ey = ry - Z*(Z\ry);
    r(j) = (ex'*ey)/sqrt((ex'*ex)*(ey'*ey));
end
end
