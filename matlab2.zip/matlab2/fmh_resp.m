function y = fmh_resp(x, kind)
%FMH_RESP Intensity-response transform on the normalised intensity x (clipped to [0,1]).
%   'linear' (default, piecewise-linear clip), 'concave' (early saturation) or
%   'sigmoid' (threshold-like). All satisfy y(0)=0, y(1)=1 and are non-decreasing.
x = min(max(x, 0), 1);
switch kind
    case 'linear',  y = x;
    case 'concave', y = (1 - exp(-3*x))/(1 - exp(-3));
    case 'sigmoid', y = x.^2./(x.^2 + (1 - x).^2);
    otherwise, error('unknown response kind');
end
end
