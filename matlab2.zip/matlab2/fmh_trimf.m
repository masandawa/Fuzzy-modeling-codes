function g = fmh_trimf(x, abc)
%FMH_TRIMF Triangular membership function with support [a,c] and core b.
a = abc(1); b = abc(2); c = abc(3);
g = zeros(size(x));
i1 = x > a & x <= b; g(i1) = (x(i1) - a)/(b - a);
i2 = x > b & x < c;  g(i2) = (c - x(i2))/(c - b);
g(x == b) = 1;
end
