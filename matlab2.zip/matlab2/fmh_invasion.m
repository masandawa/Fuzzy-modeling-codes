function [Phi, RMW] = fmh_invasion(p, d)
%FMH_INVASION Invasion factor Phi: R_M^W = R_M*sqrt(Phi) is the reproduction number of
%   malaria invading the hookworm-only equilibrium E_W (Theorem 7).
[hs, Ls] = fmh_boundary(p, d);
lam = p.beta_w*Ls/(1 + Ls);
mu = p.mu; gw = d.gw; nh = p.nuh; gm = d.gm; z = p.zeta;
Ve = [nh + lam + mu, -gw; -lam, nh + gw + mu];
Vi = [gm + lam + mu, -gw; -lam, z*gm + gw + mu];
Phi = (nh + mu)*(gm + mu)*([1, p.eta]*(Vi\(Ve\[1 - hs; d.th*hs])));
RM  = fmh_R0(p, d);
RMW = RM*sqrt(Phi);
end
