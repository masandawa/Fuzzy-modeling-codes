function fmh_make_figures(outdir)
%FMH_MAKE_FIGURES Draw the manuscript figures from the CSV files in OUTDIR.
%   Figures are saved as PDF files in OUTDIR/figs.
if nargin < 1, outdir = 'results'; end
fd = fullfile(outdir, 'figs'); if ~exist(fd, 'dir'), mkdir(fd); end
C = [42 120 214; 235 104 52; 27 175 122; 237 161 0; 232 123 164; 0 131 0]/255;   % fixed categorical order
GC = C([3 4 2], :);                                                               % group colours
lt = @(c, f) 1 - f*(1 - c);                                                       % lighten
SN = {'B: baseline','D1: semi-annual SAC','D2: semi-annual community','M: vector control', ...
      'I1: M + D2','I2: I1 + WASH'};
rd = @(f) readmatrix(fullfile(outdir, f));
T = readtable(fullfile(outdir,'core_summary.csv'));
thetaM = T.thetaM; theta_eps = T.theta_eps;
tri = @(x, a, b, c) max(min((x - a)/(b - a), (c - x)/(c - b)), 0);
HG = [24 1000 3000; 1000 3000 5000; 3000 5000 8000];          % overlapping, cross at WHO cut-offs
MG = [1 2.5 3.5; 2.5 3.5 4.5; 3.5 4.5 5];                      % log10 parasites/uL

%% Figure 2: membership functions and intensity-dependent parameters
f = figure('Color','w','Position',[100 100 900 650]);
e = linspace(0, 9000, 1801); r = logspace(0.7, 5, 2601);
subplot(2,2,1); hold on
for g = 1:3, area(e, tri(e, HG(g,1), HG(g,2), HG(g,3)), 'FaceColor', lt(GC(g,:),0.35), 'EdgeColor', GC(g,:), 'LineWidth', 1.4); end
xlabel('Hookworm intensity \epsilon (epg)'); ylabel('Membership \Gamma(\epsilon)');
title('(a) Linguistic intensity groups'); legend({'light','moderate','heavy'}, 'Box','off');
subplot(2,2,2); hold on
plot(e, min(max((e-24)/(4000-24),0),1), 'Color', C(1,:), 'LineWidth', 1.8);
plot(e, 0.95 + (thetaM - 0.95)*min(e/4000, 1), 'Color', C(2,:), 'LineWidth', 1.8);
yline(1, ':'); xlabel('\epsilon (epg)'); ylabel('Value'); title('(b) Worm-burden-dependent parameters');
legend({'\pi-hat(\epsilon)','\theta(\epsilon)'}, 'Box','off', 'Location','southeast');
subplot(2,2,3); hold on
for g = 1:3, area(r, tri(log10(r), MG(g,1), MG(g,2), MG(g,3)), 'FaceColor', lt(GC(g,:),0.35), 'EdgeColor', GC(g,:), 'LineWidth', 1.4); end
set(gca, 'XScale', 'log'); xlim([10 60000]);
xlabel('Parasite density \rho (parasites/\muL)'); ylabel('Membership \Gamma(\rho)');
title('(c) Parasite-density groups'); legend({'low','moderate','high'}, 'Box','off', 'Location','northwest');
subplot(2,2,4); hold on
plot(r, min(max((r-10)/(2000-10),0),1), 'Color', C(1,:), 'LineWidth', 1.8);
plot(r, (0.0035 + (1/30 - 0.0035)*min(max((r-10)/(10000-10),0),1))*30, 'Color', C(2,:), 'LineWidth', 1.8);
set(gca, 'XScale', 'log'); xlim([10 60000]);
xlabel('\rho (parasites/\muL)'); ylabel('Normalised value'); title('(d) Density-dependent parameters');
legend({'c-hat(\rho)','\gamma_m(\rho)/\gamma_s'}, 'Box','off', 'Location','east');
exportgraphics(f, fullfile(fd, 'fig2_membership.pdf'), 'ContentType','vector'); close(f);

%% Figure 3: reproduction numbers versus intensity
Re = rd('R_curves_eps.csv'); Rr = rd('R_curves_rho.csv'); FR = rd('fuzzy_R0_groups.csv');
CI = rd('critical_intensities.csv');
f = figure('Color','w','Position',[100 100 1000 330]);
subplot(1,3,1); hold on
plot(Re(:,1), Re(:,2), 'Color', C(1,:), 'LineWidth', 1.8);
for g = 1:3, plot(FR(g,2), FR(g,4), 'o', 'MarkerFaceColor', GC(g,:), 'MarkerEdgeColor','w', 'MarkerSize', 8); end
yline(1, ':'); xlabel('\epsilon (epg)'); ylabel('Reproduction number'); title('(a) Hookworm R_W(\epsilon)');
subplot(1,3,2); hold on
plot(Re(:,1), Re(:,3), 'Color', C(2,:), 'LineWidth', 1.8); yline(1, ':');
xlabel('\epsilon (epg)'); ylabel('\Phi(\epsilon)'); title('(b) Invasion factor');
subplot(1,3,3); hold on
plot(Rr(:,1), Rr(:,2), 'Color', C(1,:), 'LineWidth', 1.8);
for g = 1:3, plot(FR(3+g,2), FR(3+g,4), 'o', 'MarkerFaceColor', GC(g,:), 'MarkerEdgeColor','w', 'MarkerSize', 8); end
set(gca, 'XScale', 'log'); xlim([10 60000]); yline(1, ':');
xlabel('\rho (parasites/\muL)'); ylabel('R_M(\rho)'); title('(c) Malaria R_M(\rho)');
exportgraphics(f, fullfile(fd, 'fig3_R0.pdf'), 'ContentType','vector'); close(f);

%% Figure 4: fuzzy equilibria
Ee = rd('equilibria_eps.csv'); Er = rd('equilibria_rho.csv'); FE = rd('fuzzy_equilibria_alphacuts.csv');
f = figure('Color','w','Position',[100 100 900 620]);
subplot(2,2,1); hold on
plot(Ee(:,1), 100*Ee(:,3), 'Color', C(1,:), 'LineWidth', 1.8);
plot(Ee(:,1), 100*Ee(:,2), 'Color', C(2,:), 'LineWidth', 1.8);
plot(Ee(:,1), 100*Ee(:,4), 'Color', C(3,:), 'LineWidth', 1.8);
xlabel('\epsilon (epg)'); ylabel('Prevalence (%)'); title('(a) Equilibria vs worm burden');
legend({'hookworm','malaria','co-infection'}, 'Box','off');
subplot(2,2,2); hold on
plot(Er(:,1), 100*Er(:,3), 'Color', C(1,:), 'LineWidth', 1.8);
plot(Er(:,1), 100*Er(:,2), 'Color', C(2,:), 'LineWidth', 1.8);
plot(Er(:,1), 100*Er(:,4), 'Color', C(3,:), 'LineWidth', 1.8);
set(gca, 'XScale', 'log'); xlim([10 60000]);
xlabel('\rho (parasites/\muL)'); ylabel('Prevalence (%)'); title('(b) Equilibria vs parasite density');
for k = 1:2
    subplot(2,2,2+k); hold on
    for g = 1:3
        sub = FE(FE(:,1) == k & FE(:,2) == g, :); sub = sortrows(sub, 3);
        if k == 1, lo = sub(:,8); hi = sub(:,9); else, lo = sub(:,4); hi = sub(:,5); end
        x = 100*[lo; flipud(hi)]; y = [sub(:,3); flipud(sub(:,3))];
        fill(x, y, lt(GC(g,:), 0.3), 'EdgeColor', GC(g,:), 'LineWidth', 1.4);
    end
    ylabel('Membership degree \alpha');
    if k == 1
        xlabel('Co-infection prevalence (%)'); title('(c) Fuzzy co-infection, hookworm groups');
        legend({'light','moderate','heavy'}, 'Box','off');
    else
        xlabel('Malaria prevalence (%)'); title('(d) Fuzzy malaria, density groups');
        legend({'low','moderate','high'}, 'Box','off');
    end
end
exportgraphics(f, fullfile(fd, 'fig4_fuzzy_equilibria.pdf'), 'ContentType','vector'); close(f);

%% Figure 5: invasion factor over (theta, eta)
M = rd('Phi_theta_eta.csv'); thg = M(1,2:end); etg = M(2:end,1); Z = M(2:end,2:end);
f = figure('Color','w','Position',[100 100 520 380]);
contourf(thg, etg, Z, 14, 'LineStyle','none'); colormap(parula); hold on
contour(thg, etg, Z, [1 1], 'k', 'LineWidth', 1.5);
plot(theta_eps, 1.11, 'o', 'MarkerFaceColor', C(2,:), 'MarkerEdgeColor','w', 'MarkerSize', 9);
cb = colorbar; cb.Label.String = '\Phi';
xlabel('\theta'); ylabel('\eta'); title('Invasion factor \Phi (black: \Phi = 1)');
exportgraphics(f, fullfile(fd, 'fig5_phi_heatmap.pdf'), 'ContentType','vector'); close(f);

%% Figure 6: validation
H = rd('hindcast.csv'); VB = rd('validation_reinfection.csv');
f = figure('Color','w','Position',[100 100 900 340]);
subplot(1,2,1); hold on
plot(H(:,1), 100*H(:,2), 'Color', C(1,:), 'LineWidth', 1.8);
errorbar([2015.5 2021.5], [21.6 11.8], [0.3 0.4], [0.3 0.2], 'ko', 'MarkerFaceColor','k');
errorbar(2023.5, 11.3, 0.3, 0.2, 's', 'Color', C(2,:), 'MarkerFaceColor', C(2,:));
xlabel('Year'); ylabel('Malaria prevalence, SAC (%)'); title('(a) National hindcast');
legend({'model','survey (fitting)','survey 2023 (validation)'}, 'Box','off');
subplot(1,2,2); hold on
patch([15.5 36.6 36.6 15.5], [-0.05 -0.05 1.1 1.1], lt(C(2,:), 0.2), 'EdgeColor','none');
for i = 1:size(VB,1)
    plot(100*VB(i,2:3), VB(i,1)*[1 1], 'Color', C(1,:), 'LineWidth', 4);
    plot(100*VB(i,4:5), VB(i,1)*[1 1] + 0.04, 'Color', C(3,:), 'LineWidth', 4);
end
xline(25, 'Color', C(2,:)); ylim([-0.05 1.1]);
xlabel('Reinfection by week 18 (%)'); ylabel('Membership degree \alpha'); title('(b) Reinfection, Pemba');
exportgraphics(f, fullfile(fd, 'fig6_validation.pdf'), 'ContentType','vector'); close(f);

%% Figure 7: sensitivity
SI = rd('sensitivity_indices.csv'); PR = rd('prcc.csv');
nm = strtrim(splitlines(fileread(fullfile(outdir,'sensitivity_names.txt')))); nm = nm(~cellfun(@isempty, nm));
pn = strtrim(splitlines(fileread(fullfile(outdir,'prcc_names.txt')))); pn = pn(~cellfun(@isempty, pn));
f = figure('Color','w','Position',[100 100 950 420]);
subplot(1,2,1); b = barh(SI(:,2:4)); for k = 1:3, b(k).FaceColor = C(k,:); end
set(gca, 'YTick', 1:numel(nm), 'YTickLabel', nm, 'YDir','reverse', 'TickLabelInterpreter','none');
xlabel('Normalised sensitivity index'); legend({'R_M','R_W','\Phi'}, 'Box','off'); title('(a) Local indices');
subplot(1,2,2); b = barh(PR(:,[2 4])); b(1).FaceColor = C(3,:); b(2).FaceColor = C(1,:);
set(gca, 'YTick', 1:numel(pn), 'YTickLabel', pn, 'YDir','reverse', 'TickLabelInterpreter','none'); xlim([-1 1]);
xlabel('PRCC'); legend({'co-infection prevalence','malaria incidence'}, 'Box','off'); title('(b) Global PRCC');
exportgraphics(f, fullfile(fd, 'fig7_sensitivity.pdf'), 'ContentType','vector'); close(f);

%% Figure 8: scenario trajectories with alpha-cut bands
f = figure('Color','w','Position',[100 100 950 680]);
vars = {'Malaria prevalence (%)','Hookworm prevalence (%)','Co-infection prevalence (%)','Malaria infections per 1000 PY'};
cols = [2 3 4 5]; sc = [100 100 100 1]; show = [1 4 6];
for k = 1:4
    subplot(2,2,k); hold on
    for s = show
        E0 = rd(sprintf('env_a0_s%d.csv', s)); E5 = rd(sprintf('env_a50_s%d.csv', s)); E1 = rd(sprintf('env_a100_s%d.csv', s));
        t = 2026 + E0(:,1)/365;
        fill([t; flipud(t)], sc(k)*[E0(:,cols(k)); flipud(E0(:,cols(k)+5))], lt(C(s,:),0.12), 'EdgeColor','none');
        fill([t; flipud(t)], sc(k)*[E5(:,cols(k)); flipud(E5(:,cols(k)+5))], lt(C(s,:),0.28), 'EdgeColor','none');
        plot(t, sc(k)*E1(:,cols(k)), 'Color', C(s,:), 'LineWidth', 1.6);
    end
    xlabel('Year'); ylabel(vars{k});
end
exportgraphics(f, fullfile(fd, 'fig8_scenarios.pdf'), 'ContentType','vector'); close(f);

%% Figure 9: fuzzy 2030 outcomes against the WHO benchmarks
O = rd('scenario_samples.csv'); al = [0 0.25 0.5 0.75 1];
f = figure('Color','w','Position',[100 100 950 360]);
for k = 1:2
    subplot(1,2,k); hold on
    for s = 1:6
        for a = al
            sub = O(O(:,1) == a & O(:,2) == s, :); if isempty(sub), continue; end
            v = sub(:, 4); if k == 2, v = 100*sub(:, 8); end
            plot([min(v) max(v)], [s s], 'Color', lt(C(s,:), 0.25 + 0.75*a), 'LineWidth', 3 + 9*a);
        end
    end
    set(gca, 'YTick', 1:6, 'YTickLabel', SN, 'YDir','reverse');
    if k == 1, xline(80, '--r'); xlabel('Reduction in malaria incidence 2030 vs 2026 (%)');
    else, xline(2, '--r'); xlabel('Moderate/heavy hookworm prevalence 2030 (%)'); end
end
exportgraphics(f, fullfile(fd, 'fig9_targets.pdf'), 'ContentType','vector'); close(f);
%% Figure: bifurcation diagram and global convergence
BD = rd('bifurcation.csv'); GCv = rd('global_convergence.csv'); GF = rd('global_regimes.csv');
f = figure('Color','w','Position',[100 100 1000 700]);
subplot(2,5,[1 2]); hold on
plot(BD(:,1), 100*BD(:,4), '--', 'Color', [0.32 0.32 0.31], 'LineWidth', 1.5);
plot(BD(:,1), 100*BD(:,3), 'Color', C(1,:), 'LineWidth', 2);
xline(1, ':'); xline(interp1(BD(:,2), BD(:,1), 1), ':', 'Color', C(2,:));
xlabel('R_M (varying m_v)'); ylabel('Malaria prevalence (%)'); title('(a) Bifurcation diagram');
legend({'without hookworm','with hookworm'}, 'Box','off', 'Location','northwest');
subplot(2,5,[3 4]); plot(BD(:,1), 1e3*BD(:,5), 'Color', C(1,:), 'LineWidth', 1.6); yline(0);
xlabel('R_M'); ylabel('max Re(\lambda) (10^{-3}/day)'); title('(b) Stability');
ttl = {'(c) E_0','(d) E_W','(e) E_M','(f) hookworm-sustained','(g) E^*'};
for r = 1:5
    subplot(2,5,5+r); hold on
    for n = 1:25
        k = GCv(:,1) == r & GCv(:,2) == n;
        plot(100*GCv(k,5), 100*GCv(k,4), 'Color', lt(C(r,:), 0.55));
    end
    plot(100*GF(r,6), 100*GF(r,5), 'ko', 'MarkerFaceColor','k');
    title(ttl{r}); xlabel('Hookworm (%)'); if r == 1, ylabel('Malaria (%)'); end
end
exportgraphics(f, fullfile(fd, 'fig_bifurcation.pdf'), 'ContentType','vector'); close(f);

%% Figure: critical deworming coverage
PC = rd('critical_coverage_curve.csv'); FCv = rd('fuzzy_critical_coverage.csv');
f = figure('Color','w','Position',[100 100 900 330]);
subplot(1,2,1); hold on
pa = PC(:,2); pa(pa > 1) = NaN; ps = PC(:,3); ps(ps > 1) = NaN;
plot(PC(:,1), 100*pa, 'Color', C(1,:), 'LineWidth', 1.8); plot(PC(:,1), 100*ps, 'Color', C(2,:), 'LineWidth', 1.8);
yline(75, '--r'); yline(22.5, ':'); xlim([0 4500]); ylim([0 105]);
xlabel('\epsilon (epg)'); ylabel('\phi_c (%)'); title('(a) Critical coverage'); legend({'annual','semi-annual'}, 'Box','off');
subplot(1,2,2); hold on
sub = sortrows(FCv(FCv(:,1) == 1, :), 2);
fill(100*min([sub(:,3); flipud(sub(:,4))], 1.05), [sub(:,2); flipud(sub(:,2))], lt(C(1,:),0.25), 'EdgeColor', C(1,:));
fill(100*min([sub(:,5); flipud(sub(:,6))], 1.05), [sub(:,2); flipud(sub(:,2))], lt(C(2,:),0.25), 'EdgeColor', C(2,:));
xline(75, '--r'); xlim([0 106]); xlabel('\phi_c (%) (>100: unattainable)'); ylabel('\alpha'); title('(b) Fuzzy \phi_c, light group');
exportgraphics(f, fullfile(fd, 'fig_coverage.pdf'), 'ContentType','vector'); close(f);
end
