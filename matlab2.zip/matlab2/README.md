# MATLAB code: fuzzy malaria–hookworm co-infection model (revised)

Code accompanying the manuscript *"A fuzzy mathematical model of malaria–hookworm co-infection with intensity-dependent parameters: assessing integrated deworming and malaria control towards the WHO 2030 targets"* (revised version: SEIRS malaria × SIS hookworm, 12 equations).

## How to run

```matlab
% MATLAB R2020a or later; Optimization Toolbox (fsolve)
main_fuzzy_malaria_hookworm      % all analyses; writes CSV files to ./results
fmh_make_figures('results')      % draws the figures into ./results/figs
```

Set `MAKE_FIGS = true` at the top of the main script to draw the figures automatically. A full run takes roughly 1–1.5 hours on a laptop, mostly in Section 7 (fuzzy scenario propagation over 213 recalibrations). The code runs unchanged in GNU Octave 8.4, which was used to produce the numbers in the manuscript; the `results` folder contains those outputs.

## Model

State vector `y = [s0 e0 i0 r0 s1 e1 i1 r1 L sv ev iv]`: index 0 = hookworm-free, 1 = hookworm carriers; s, e, i, r = malaria susceptible, exposed (liver stage), infectious, temporarily immune; L = infective larvae in soil; sv, ev, iv = mosquitoes.

## Files

| File | Purpose |
|---|---|
| `main_fuzzy_malaria_hookworm.m` | Driver: Sections 1–7 (calibration, validation, fuzzy R0 with overlapping groups, critical coverage, fuzzy equilibria, bifurcation diagram, global convergence, identifiability, sensitivity, scenarios) |
| `fmh_params.m` | Core parameter values (Table 2 of the manuscript) |
| `fmh_shape.m` | Intensity-dependent functions π̂(ε), θ(ε), ĉ(ρ), γ_m(ρ) |
| `fmh_derived.m` | Group-level parameters for given (ε, ρ) |
| `fmh_rhs.m` | Right-hand side of the 12-equation model |
| `fmh_R0.m` | R_M, R_W, R_0 |
| `fmh_boundary.m` | Explicit boundary equilibria E_W and E_M |
| `fmh_invasion.m` | Invasion factor Φ and R_M^W (matrix formula) |
| `fmh_bifcoef.m` | Centre-manifold coefficients a, b of the co-infection bifurcation at R_M^W = 1 |
| `fmh_critcov.m` | Critical deworming coverage φ_c |
| `fmh_critcov_imp.m` | Exact critical coverage for periodic deworming rounds (Floquet monodromy, Proposition 2); writes `results/critical_coverage_impulsive.csv` |
| `fmh_equilibrium.m`, `fmh_eqrobust.m`, `fmh_ic.m` | Equilibria (Newton with threshold checks; ODE fallback) |
| `fmh_jac.m`, `fmh_red.m`, `fmh_maxeig.m` | Reduced Jacobian and stability check |
| `fmh_calibrate.m` | Closed-form calibration of m_v, π_max, θ_M to (P_m, P_w, OR) |
| `fmh_simulate.m`, `fmh_schedule.m` | Simulation with impulsive deworming |
| `fmh_hindcast.m`, `fmh_hindcast_at.m` | National malaria hindcast 2015–2023 (validation V1) |
| `fmh_mhi.m` | Moderate/heavy-intensity hookworm prevalence |
| `fmh_trimf.m`, `fmh_alphacut.m`, `fmh_fev.m`, `fmh_cutvals.m` | Triangular membership, α-cuts, fuzzy expected value, extension principle |
| `fmh_prcc.m` | Partial rank correlation coefficients |
| `fmh_writecsv.m` | CSV writer |
| `fmh_make_figures.m` | Figures from the CSV results |

## Outputs (./results)

`core_summary.csv`, `hindcast*.csv`, `validation_reinfection.csv`, `fuzzy_R0_groups.csv`, `fuzzy_invasion_groups.csv`, `R_curves_*.csv`, `critical_intensities.csv`, `critical_coverage_curve.csv`, `fuzzy_critical_coverage.csv`, `equilibria_*.csv`, `fuzzy_equilibria_alphacuts.csv`, `Phi_theta_eta.csv`, `bifurcation.csv`, `global_convergence.csv`, `global_regimes.csv`, `identifiability.csv`, `sensitivity_indices.csv`, `prcc.csv`, `scenario_samples.csv`, `calibration_samples.csv`, `env_a{α}_s{scenario}.csv`.

## Note on figures

The manuscript figures were drawn from these CSV files with `make_figs.py` (in the LaTeX package), because the runs were done in GNU Octave. `fmh_make_figures.m` draws the same figures natively in MATLAB from the same files.

## Robustness checks (folder `checks/`)

Run from MATLAB/Octave after the main script (they read `results/hindcast_summary.csv`):

| Script | Purpose | Output |
|---|---|---|
| `checks/conv_static.m` | Convergence of alpha-cuts of theta(eps), Phi, R_M, R_W for 53/200/500/1000 points per level; multistart Nelder-Mead extrema | `results/conv_static.csv`, `results/conv_static_opt.csv` |
| `checks/conv_scen.m` | Scenario outcomes (B, D2, M, I1) for larger designs and periodic-baseline check. Set `N` and `alv` first, e.g. `N=500; alv=[0 0.25 0.5 0.75]; run checks/conv_scen.m` | `results/conv_scen_<N>_<alphas>.csv` |
| `checks/alt_shapes.m` | Principal results under concave and sigmoid intensity-response forms | `results/structural_sensitivity.csv` |
| `checks/alt_shapes_fuzzy.m` | Facilitation necessity and identifiability under the alternative forms | `results/structural_fuzzy.csv`, `results/structural_ident.csv` |

Helper functions: `fmh_resp.m` (response forms; set `p.shape_eps`, `p.shape_rho`), `fmh_design.m`, `fmh_fuzzyinputs.m`, `fmh_sample.m`, `fmh_static_out.m`.
