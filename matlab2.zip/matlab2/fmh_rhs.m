function dy = fmh_rhs(~, y, p, d)
%FMH_RHS Right-hand side of the malaria-hookworm co-infection model (proportions).
%   y = [s0 e0 i0 r0 s1 e1 i1 r1 L sv ev iv]
%   index 0: hookworm-free hosts; index 1: hookworm carriers.
%   s: malaria-susceptible, e: malaria-exposed (liver stage), i: malaria-infectious,
%   r: recovered with temporary malaria immunity; L: infective larvae in soil;
%   sv, ev, iv: susceptible, exposed and infectious mosquitoes.
s0 = y(1); e0 = y(2); i0 = y(3); r0 = y(4); s1 = y(5); e1 = y(6); i1 = y(7); r1 = y(8);
L = y(9); sv = y(10); ev = y(11); iv = y(12);
lam_m = p.a*(1-p.u)*p.b*p.mv*iv;               % force of malaria infection
lam_w = p.beta_w*L/(1+L);                      % force of hookworm infection
lam_v = p.a*(1-p.u)*d.cr*(i0 + p.eta*i1);      % force of infection on mosquitoes
gm = d.gm; gw = d.gw; th = d.th; z = p.zeta; mu = p.mu; nh = p.nuh; ps = p.psi;
dy = zeros(12,1);
dy(1) = mu - (lam_m + lam_w + mu)*s0 + ps*r0 + gw*s1;
dy(2) = lam_m*s0 - (nh + lam_w + mu)*e0 + gw*e1;
dy(3) = nh*e0 - (gm + lam_w + mu)*i0 + gw*i1;
dy(4) = gm*i0 - (ps + lam_w + mu)*r0 + gw*r1;
dy(5) = lam_w*s0 - (th*lam_m + gw + mu)*s1 + ps*r1;
dy(6) = th*lam_m*s1 + lam_w*e0 - (nh + gw + mu)*e1;
dy(7) = nh*e1 + lam_w*i0 - (z*gm + gw + mu)*i1;
dy(8) = z*gm*i1 + lam_w*r0 - (ps + gw + mu)*r1;
dy(9) = (1-p.wash)*d.pi*(s1 + e1 + i1 + r1) - p.muL*L;
dy(10) = p.muv - (lam_v + p.muv)*sv;
dy(11) = lam_v*sv - (p.nuv + p.muv)*ev;
dy(12) = p.nuv*ev - p.muv*iv;
end
