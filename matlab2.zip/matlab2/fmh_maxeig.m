function lmax = fmh_maxeig(p, d, y)
%FMH_MAXEIG Largest real part of the eigenvalues of the (reduced) Jacobian at state y.
lmax = max(real(eig(fmh_jac(p, d, y))));
end
