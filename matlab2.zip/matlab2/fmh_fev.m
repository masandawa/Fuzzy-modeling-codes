function [F, H, alph] = fmh_fev(f, G)
%FMH_FEV Fuzzy expected value FEV[f] = sup_alpha min(alpha, mu{f >= alpha}) of a function
%   f in [0,1] sampled on a grid, with possibility measure mu(A) = sup_{x in A} G(x).
alph = linspace(0, 1, 2001);
H = zeros(size(alph));
for k = 1:numel(alph)
    idx = f >= alph(k);
    if any(idx), H(k) = max(G(idx)); end
end
F = max(min(alph, H));
end
