function y = fmh_eqrobust(p, d, ywarm)
%FMH_EQROBUST Stable equilibrium for given (eps, rho). Newton from a warm start is
%   accepted only if it is non-negative and consistent with the threshold theorems
%   (hookworm present iff R_W > 1; malaria present iff R_M > 1 (R_W <= 1) or
%   R_M^W > 1 (R_W > 1)); otherwise the long-time limit of the ODE is used.
[RM, RW] = fmh_R0(p, d);
if RW > 1, [~, Rmal] = fmh_invasion(p, d); else, Rmal = RM; end
y = fmh_equilibrium(p, d, ywarm);
hasW = sum(y(5:8)) > 1e-8; hasM = y(3) + y(7) > 1e-8;
if any(y < -1e-9) || any(~isfinite(y)) || hasW ~= (RW > 1) || hasM ~= (Rmal > 1)
    opts = odeset('RelTol',1e-8,'AbsTol',1e-12);
    [~, Y] = ode45(@(t,yy) fmh_rhs(t,yy,p,d), [0 150*365], fmh_ic(), opts);
    y = Y(end,:)';
    y(y < 0 & y > -1e-9) = 0;
end
end
