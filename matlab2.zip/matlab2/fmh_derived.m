function d = fmh_derived(p, eps, rho, averaged)
%FMH_DERIVED Group-level parameter values for intensity eps (epg) and density rho (p/uL).
if nargin < 2 || isempty(eps), eps = p.eps; end
if nargin < 3 || isempty(rho), rho = p.rho; end
if nargin < 4, averaged = true; end
[pih, th, ch, gm] = fmh_shape(p, eps, rho);
d.th = th; d.pi = p.pimax*pih; d.cr = p.cmax*ch; d.gm = gm;
d.tau = -log(1 - p.phi*p.CR)/p.T;      % averaged deworming rate
d.gw = p.gw0 + averaged*d.tau;
end
