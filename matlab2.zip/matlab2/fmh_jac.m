function J = fmh_jac(p, d, y)
%FMH_JAC Jacobian of the reduced 10-dimensional system (s0 and sv eliminated by
%   conservation) at state y, by central finite differences.
x = y([2:9 11 12]); n = numel(x); J = zeros(n);
for k = 1:n
    h = 1e-7*max(1, abs(x(k)));
    xp = x; xm = x; xp(k) = xp(k) + h; xm(k) = xm(k) - h;
    J(:,k) = (fmh_red(xp, p, d) - fmh_red(xm, p, d))/(2*h);
end
end
