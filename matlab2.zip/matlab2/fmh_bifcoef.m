function [a, b, mvc, w] = fmh_bifcoef(p)
%FMH_BIFCOEF Centre-manifold coefficients (Castillo-Chavez & Song 2004) of the
%   transcritical bifurcation of malaria from the hookworm-only equilibrium E_W at
%   R_M^W = 1, with bifurcation parameter mv. a < 0 and b > 0 imply a forward
%   bifurcation and local asymptotic stability of the co-existence equilibrium for
%   R_M^W slightly above one. Uses the reduced system (fmh_red).
d = fmh_derived(p);
[~, RMW] = fmh_invasion(p, d);
mvc = p.mv/RMW^2;                       % R_M^W is proportional to sqrt(mv)
q = p; q.mv = mvc;
[~, ~, ~, yW] = fmh_boundary(q, d);
x0 = yW([2:9 11 12]);
J = fmh_jac(q, d, yW);
[Vr, Dr] = eig(J);  [~, k] = min(abs(diag(Dr))); w = real(Vr(:,k));
[Vl, Dl] = eig(J'); [~, k] = min(abs(diag(Dl))); v = real(Vl(:,k));
if w(3) < 0, w = -w; end                 % malaria-infectious component positive
v = v/(v'*w);
h = 1e-4;
D2 = (fmh_red(x0 + h*w, q, d) - 2*fmh_red(x0, q, d) + fmh_red(x0 - h*w, q, d))/h^2;
a = v'*D2;
dm = 1e-6*mvc; qp = q; qp.mv = mvc + dm; qm = q; qm.mv = mvc - dm;
Jb = (fmh_jac(qp, d, yW) - fmh_jac(qm, d, yW))/(2*dm);
b = v'*Jb*w;
end
