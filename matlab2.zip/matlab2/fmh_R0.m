function [RM, RW, R0] = fmh_R0(p, d)
%FMH_R0 Basic reproduction numbers (spectral radius of the next-generation matrix).
RM = sqrt((p.a*(1-p.u))^2*p.b*d.cr*p.mv*p.nuv*p.nuh./ ...
          (p.muv*(p.nuv+p.muv)*(p.nuh + p.mu)*(d.gm + p.mu)));
RW = p.beta_w*(1-p.wash)*d.pi./(p.muL*(d.gw + p.mu));
R0 = max(RM, RW);
end
