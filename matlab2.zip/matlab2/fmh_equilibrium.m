function y = fmh_equilibrium(p, d, y0)
%FMH_EQUILIBRIUM Equilibrium by (optional) long integration followed by Newton polishing.
if nargin < 3 || isempty(y0)
    opts = odeset('RelTol',1e-6,'AbsTol',1e-9);
    [~, Y] = ode45(@(t,y) fmh_rhs(t,y,p,d), [0 80*365], fmh_ic(), opts);
    y0 = Y(end,:)';
end
F = @(x) fmh_eqres(x, p, d);
x0 = y0([2:9 11 12]);
o = optimset('Display','off','TolFun',1e-14,'TolX',1e-14,'MaxIter',400);
x = fsolve(F, x0, o);
y = fmh_full(x);
end

function r = fmh_eqres(x, p, d)
f = fmh_rhs(0, fmh_full(x), p, d);
r = f([2:9 11 12]);
end

function y = fmh_full(x)
y = [1 - sum(x(1:7)); x(1:8); 1 - x(9) - x(10); x(9:10)];
end
