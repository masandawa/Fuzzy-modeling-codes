function [t, Y] = fmh_simulate(p, y0, tspan, mda, dtout)
%FMH_SIMULATE Integrate the model on tspan=[t0 t1] (days) with impulsive deworming.
%   mda: matrix with rows [time, coverage]; at each time a fraction coverage*CR of
%   hookworm carriers in every malaria state is cured (x1 -> x0, x in {s,e,i,r}).
%   Continuous (averaged) deworming is switched off.
d = fmh_derived(p, [], [], false);
opts = odeset('RelTol',1e-7,'AbsTol',1e-10);
tgrid = unique([tspan(1):dtout:tspan(2), tspan(2)]);
Y = zeros(12, numel(tgrid)); Y(:,1) = y0(:);
if isempty(mda), mda = zeros(0,2); end
mda = mda(mda(:,1) > tspan(1) & mda(:,1) < tspan(2), :);
ev = [mda(:,1); tspan(2)];
tc = tspan(1); y = y0(:);
for k = 1:numel(ev)
    te = ev(k);
    if te > tc
        idx = find(tgrid > tc & tgrid <= te);
        tt = unique([tc, tgrid(idx), te]);
        [ts, Ys] = ode45(@(t,yy) fmh_rhs(t,yy,p,d), tt, y, opts);
        if numel(tt) == 2, Ys = Ys([1 end],:); ts = ts([1 end]); end
        for j = idx
            Y(:,j) = Ys(abs(ts - tgrid(j)) < 1e-9, :)';
        end
        y = Ys(end,:)'; tc = te;
    end
    if k <= size(mda,1)
        f = mda(k,2)*p.CR;
        moved = f*y(5:8);
        y(5:8) = y(5:8) - moved; y(1:4) = y(1:4) + moved;
    end
end
t = tgrid;
end
