function [tt, Pm] = fmh_hindcast(q, y0, umax, years)
%FMH_HINDCAST National malaria trajectory from mid-2015 with vector-control scale-up:
%   u(t) increases linearly from 0 (mid-2015) to umax (mid-2021) and is constant after.
dt = 30; tt = unique([0:dt:years*365, years*365]); Pm = zeros(size(tt)); Pm(1) = y0(3) + y0(7);
y = y0(:);
for k = 2:numel(tt)
    tm = 0.5*(tt(k-1) + tt(k));
    q.u = umax*min(tm/(6*365), 1);
    mda = fmh_schedule('annual', q.phi, tt(k-1), tt(k));
    [~, Y] = fmh_simulate(q, y, [tt(k-1) tt(k)], mda, dt);
    y = Y(:, end);
    Pm(k) = y(3) + y(7);
end
end
