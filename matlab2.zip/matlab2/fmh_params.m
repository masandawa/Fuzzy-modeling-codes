function p = fmh_params()
%FMH_PARAMS Baseline (core) parameter values of the fuzzy malaria-hookworm model.
%   Time unit: days. Values marked (cal) are obtained by calibration.
p.mu      = 1/(66*365);   % human natural mortality (= birth) rate
p.a       = 0.33;         % mosquito biting rate (Chitnis et al. 2008)
p.b       = 0.022;        % prob. of mosquito-to-human transmission per bite (Chitnis et al. 2008)
p.cmax    = 0.48;         % max prob. of human-to-mosquito transmission per bite (Chitnis et al. 2008)
p.nuh     = 0.10;         % 1/latent (liver-stage) period in humans (Chitnis et al. 2008)
p.psi     = 2.7e-3;       % loss of temporary malaria immunity (Chitnis et al. 2008)
p.nuv     = 0.091;        % 1/extrinsic incubation period (Chitnis et al. 2008)
p.muv     = 1/14;         % mosquito mortality rate
p.mv      = NaN;          % mosquito:human ratio (cal)
p.ga      = 0.0035;       % recovery rate from low-density (asymptomatic) infection (Chitnis et al. 2008)
p.gs      = 1/30;         % recovery rate from high-density (clinical, treated) infection
p.rho_min = 10;           % parasite density below which infectiousness is negligible (p/uL)
p.rho_c   = 2000;         % density at which infectiousness to mosquitoes saturates (p/uL)
p.rho_M   = 10000;        % density above which infections are clinical/treated (p/uL)
p.eps_d   = 24;           % Kato-Katz detection limit (epg)
p.eps_M   = 4000;         % WHO heavy-intensity threshold for hookworm (epg)
p.gw0     = 1/730;        % natural loss rate of hookworm infection
p.muL     = 1/21;         % mortality of infective L3 larvae in soil
p.beta_w  = 0.005;        % maximal per-capita larval infection rate
p.pimax   = NaN;          % maximal environmental contamination rate (cal)
p.theta0  = 0.95;         % malaria-susceptibility modifier at negligible worm burden
p.thetaM  = NaN;          % malaria-susceptibility modifier at heavy intensity (cal)
p.eta     = 1.11;         % relative infectiousness of co-infected humans to mosquitoes
p.zeta    = 0.85;         % relative malaria recovery rate in co-infected humans
p.CR      = 0.72;         % albendazole cure rate against hookworm (Keiser & Utzinger 2008)
p.phi     = 0.75*0.30;    % effective community coverage of school-based deworming
p.T       = 365;          % interval between deworming rounds (days)
p.u       = 0;            % additional reduction of effective biting (vector control)
p.wash    = 0;            % reduction of environmental contamination (WASH)
p.eps     = 600;          % representative intensity among hookworm-infected (epg)
p.rho     = 1000;         % representative parasite density among malaria-infected (p/uL)
p.ke      = 1.0;          % shape of the epg distribution among infected hosts
p.kw      = 0.35;         % aggregation parameter of the worm burden
end
