function M = fmh_mhi(P, p, eps0, P0)
%FMH_MHI Prevalence of moderate/heavy-intensity (>=2000 epg) hookworm infection.
%   Mean intensity among infected scales with the mean worm burden per infected host
%   (negative binomial worm distribution, aggregation kw); epg among infected ~ Gamma(ke).
mb = @(Q) p.kw*((1 - min(max(Q,1e-9),0.999)).^(-1/p.kw) - 1);
ratio = (mb(P)./max(P,1e-12))./(mb(P0)/P0);
epsbar = eps0*ratio;
frac = gammainc(2000*p.ke./max(epsbar,1e-9), p.ke, 'upper');
M = P.*frac;
end
