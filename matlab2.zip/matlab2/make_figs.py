"""Render manuscript figures from the CSV results written by main_fuzzy_malaria_hookworm.m."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import to_rgb

R = '/home/claude/matlab2/results/'
F = '/home/claude/paper3/'
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED = ('#2a78d6', '#eb6834', '#1baf7a', '#eda100',
                                                         '#e87ba4', '#008300', '#6250d6', '#e34948')
SC = [BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN]
SN = ['B: baseline', 'D1: semi-annual SAC', 'D2: semi-annual community', 'M: vector control',
      'I1: M + D2', 'I2: I1 + WASH']
INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2,
                     'ytick.color': INK2, 'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.6,
                     'axes.spines.top': False, 'axes.spines.right': False, 'legend.frameon': False,
                     'lines.linewidth': 1.8, 'font.family': 'DejaVu Sans', 'savefig.dpi': 300})

def light(c, f):
    r, g, b = to_rgb(c); return (1 - f*(1 - r), 1 - f*(1 - g), 1 - f*(1 - b))

core = pd.read_csv(R + 'core_summary.csv').iloc[0]
P = dict(theta0=0.95, thetaM=core['thetaM'], eps_d=24, eps_M=4000, rho_min=10, rho_c=2000, rho_M=10000,
         ga=0.0035, gs=1/30)

def trimf(x, a, b, c):
    return np.clip(np.minimum((x - a)/(b - a), (c - x)/(c - b)), 0, 1)

HG = [(24, 1000, 3000), (1000, 3000, 5000), (3000, 5000, 8000)]
MG = [(1, 2.5, 3.5), (2.5, 3.5, 4.5), (3.5, 4.5, 5.0)]   # log10 parasites/uL
HC = [(0, 2000), (2000, 4000), (4000, 9000)]; MC = [(10, 1e3), (1e3, 1e4), (1e4, 1e5)]   # crisp WHO classes
HN = ['light', 'moderate', 'heavy']; MN = ['low', 'moderate', 'high']
GC = [AQUA, YELLOW, RED]

# ---------- Fig 2: membership and intensity-dependent parameter functions ----------
fig, ax = plt.subplots(2, 2, figsize=(7.2, 5.2))
e = np.linspace(0, 9000, 1801); r = np.logspace(0.7, 5, 2601)
for g, n, c in zip(HG, HN, GC):
    ax[0, 0].fill_between(e, 0, trimf(e, *g), color=light(c, 0.35), lw=0, alpha=0.8)
    ax[0, 0].plot(e, trimf(e, *g), color=c, lw=1.4, label=n)
ax[0, 0].set(xlabel='Hookworm intensity $\\epsilon$ (eggs per gram)', ylabel='Membership $\\Gamma(\\epsilon)$',
             title='(a) Linguistic intensity groups (WHO cut-offs)')
ax[0, 0].legend(loc='upper right')
pih = np.clip((e - 24)/(4000 - 24), 0, 1); th = P['theta0'] + (P['thetaM'] - P['theta0'])*np.clip(e/4000, 0, 1)
ax[0, 1].plot(e, pih, color=BLUE, label='$\\hat\\pi(\\epsilon)$ egg contamination')
ax[0, 1].plot(e, th, color=ORANGE, label='$\\theta(\\epsilon)$ malaria susceptibility')
ax[0, 1].axhline(1, color=INK2, lw=0.8, ls=':')
ax[0, 1].set(xlabel='Hookworm intensity $\\epsilon$ (epg)', ylabel='Value', title='(b) Worm-burden-dependent parameters')
ax[0, 1].legend(loc='center right', fontsize=7.5)
for g, n, c in zip(MG, MN, GC):
    ax[1, 0].fill_between(r, 0, trimf(np.log10(r), *g), color=light(c, 0.35), lw=0, alpha=0.8)
    ax[1, 0].plot(r, trimf(np.log10(r), *g), color=c, lw=1.4, label=n)
ax[1, 0].set_xscale('log'); ax[1, 0].set_xlim(10, 1e5)
ax[1, 0].set(xlabel='Parasite density $\\rho$ (parasites/$\\mu$L)', ylabel='Membership $\\Gamma(\\rho)$',
             title='(c) Linguistic parasite-density groups')
ax[1, 0].legend(loc='upper left')
ch = np.clip((r - 10)/(2000 - 10), 0, 1)
gm = 0.0035 + (1/30 - 0.0035)*np.clip((r - 10)/(10000 - 10), 0, 1)
ax[1, 1].plot(r, ch, color=BLUE, label='$\\hat c(\\rho)$ infectiousness')
ax[1, 1].plot(r, gm/(1/30), color=ORANGE, label='$\\gamma_m(\\rho)/\\gamma_s$ clearance')
ax[1, 1].set_xscale('log'); ax[1, 1].set_xlim(5, 6e4)
ax[1, 1].set(xlabel='Parasite density $\\rho$ (parasites/$\\mu$L)', ylabel='Normalised value',
             title='(d) Density-dependent parameters')
ax[1, 1].legend(loc='center right')
fig.tight_layout(); fig.savefig(F + 'fig2_membership.pdf'); plt.close(fig)

# ---------- Fig 3: reproduction numbers by intensity ----------
Re = pd.read_csv(R + 'R_curves_eps.csv'); Rr = pd.read_csv(R + 'R_curves_rho.csv')
FR = pd.read_csv(R + 'fuzzy_R0_groups.csv')
fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.7))
for g, c in zip(HC, GC):
    ax[0].axvspan(g[0], g[1], color=light(c, 0.15), lw=0)
ax[0].plot(Re.eps, Re.RW, color=BLUE, label='$\\mathcal{R}_W(\\epsilon)$')
for i in range(3):
    ax[0].plot(FR.modal[i], FR.R_fuzzy[i], 'o', ms=6, color=GC[i], mec='white', mew=1)
ax[0].axhline(1, color=INK2, lw=0.8, ls=':')
ax[0].set(xlabel='$\\epsilon$ (epg)', ylabel='Reproduction number', title='(a) Hookworm', xlim=(0, 9000))
ax[1].plot(Re.eps, Re.Phi, color=ORANGE)
ax[1].axhline(1, color=INK2, lw=0.8, ls=':')
ci = pd.read_csv(R + 'critical_intensities.csv').iloc[0]
ax[1].axvline(ci.eps_RW1, color=INK2, lw=0.8, ls='--')
ax[1].text(ci.eps_RW1 + 200, 0.98*Re.Phi.max(), '$\\mathcal{R}_W=1$ at\n%d epg' % round(ci.eps_RW1), color=INK2, fontsize=8, va='top')
ax[1].set(xlabel='$\\epsilon$ (epg)', ylabel='Invasion factor $\\Phi(\\epsilon)$', title='(b) Hookworm effect on malaria',
          xlim=(0, 9000))
for g, c in zip(MC, GC):
    ax[2].axvspan(g[0], g[1], color=light(c, 0.15), lw=0)
ax[2].plot(Rr.rho, Rr.RM, color=BLUE)
for i in range(3):
    ax[2].plot(FR.modal[3+i], FR.R_fuzzy[3+i], 'o', ms=6, color=GC[i], mec='white', mew=1)
ax[2].axhline(1, color=INK2, lw=0.8, ls=':')
ax[2].set_xscale('log'); ax[2].set_xlim(10, 1e5)
ax[2].set(xlabel='$\\rho$ (parasites/$\\mu$L)', ylabel='$\\mathcal{R}_M(\\rho)$', title='(c) Malaria')
fig.tight_layout(); fig.savefig(F + 'fig3_R0.pdf'); plt.close(fig)

# ---------- Fig 4: fuzzy equilibria ----------
Ee = pd.read_csv(R + 'equilibria_eps.csv'); Er = pd.read_csv(R + 'equilibria_rho.csv')
FE = pd.read_csv(R + 'fuzzy_equilibria_alphacuts.csv')
fig, ax = plt.subplots(2, 2, figsize=(7.2, 5.0))
ax[0, 0].plot(Ee.eps, 100*Ee.Pw, color=BLUE, label='hookworm')
ax[0, 0].plot(Ee.eps, 100*Ee.Pm, color=ORANGE, label='malaria')
ax[0, 0].plot(Ee.eps, 100*Ee.Pc, color=AQUA, label='co-infection')
ax[0, 0].set(xlabel='Hookworm intensity $\\epsilon$ (epg)', ylabel='Equilibrium prevalence (%)', title='(a) Equilibria vs worm burden')
ax[0, 0].legend(loc='center right')
ax[0, 1].plot(Er.rho, 100*Er.Pw, color=BLUE, label='hookworm')
ax[0, 1].plot(Er.rho, 100*Er.Pm, color=ORANGE, label='malaria')
ax[0, 1].plot(Er.rho, 100*Er.Pc, color=AQUA, label='co-infection')
ax[0, 1].set_xscale('log'); ax[0, 1].set_xlim(10, 1e5)
ax[0, 1].set(xlabel='Parasite density $\\rho$ (parasites/$\\mu$L)', ylabel='Equilibrium prevalence (%)', title='(b) Equilibria vs parasite density')
def memb(ax_, sub, lo, hi, c, lab):
    sub = sub.sort_values('alpha')
    x = np.concatenate([100*sub[lo].values, 100*sub[hi].values[::-1]])
    y = np.concatenate([sub.alpha.values, sub.alpha.values[::-1]])
    ax_.fill(x, y, color=light(c, 0.3), lw=0); ax_.plot(x, y, color=c, lw=1.4, label=lab)
for g in range(3):
    memb(ax[1, 0], FE[(FE.disease == 1) & (FE.group == g+1)], 'Pc_lo', 'Pc_hi', GC[g], HN[g])
ax[1, 0].set(xlabel='Co-infection prevalence (%)', ylabel='Membership degree $\\alpha$', title='(c) Fuzzy co-infection, hookworm groups')
ax[1, 0].legend()
for g in range(3):
    memb(ax[1, 1], FE[(FE.disease == 2) & (FE.group == g+1)], 'Pm_lo', 'Pm_hi', GC[g], MN[g])
ax[1, 1].set(xlabel='Malaria prevalence (%)', ylabel='Membership degree $\\alpha$', title='(d) Fuzzy malaria, density groups')
ax[1, 1].legend()
fig.tight_layout(); fig.savefig(F + 'fig4_fuzzy_equilibria.pdf'); plt.close(fig)

# ---------- Fig 5: Phi heat map ----------
M = pd.read_csv(R + 'Phi_theta_eta.csv', header=None, skiprows=1).values
thg = M[0, 1:]; etg = M[1:, 0]; Z = M[1:, 1:]
fig, ax = plt.subplots(figsize=(4.6, 3.3))
cs = ax.contourf(thg, etg, Z, levels=14, cmap='Blues')
c1 = ax.contour(thg, etg, Z, levels=[1.0], colors=[INK], linewidths=1.5)
ax.clabel(c1, fmt='$\\Phi=1$', fontsize=8)
ax.plot(core['theta_eps'], 1.11, 'o', color=ORANGE, mec='white', ms=7)
ax.annotate('calibrated\nLake Zone', (core['theta_eps'], 1.11), xytext=(10, 12), textcoords='offset points', fontsize=8, color=INK)
cb = fig.colorbar(cs); cb.set_label('Invasion factor $\\Phi$')
ax.set(xlabel='Malaria susceptibility modifier $\\theta$', ylabel='Infectiousness modifier $\\eta$')
ax.grid(False); fig.tight_layout(); fig.savefig(F + 'fig5_phi_heatmap.pdf'); plt.close(fig)

# ---------- Fig 6: validation ----------
H = pd.read_csv(R + 'hindcast.csv'); VB = pd.read_csv(R + 'validation_reinfection.csv')
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9))
ax[0].plot(H.year, 100*H.Pm, color=BLUE, label='model (fitted to 2015, 2021)')
ax[0].errorbar([2015.5, 2021.5], [21.6, 11.8], yerr=[[0.3, 0.3], [0.4, 0.2]], fmt='o', color=INK, ms=5, label='survey (fitting)')
ax[0].errorbar([2023.5], [11.3], yerr=[[0.3], [0.2]], fmt='s', color=ORANGE, ms=6, label='survey 2023 (validation)')
ax[0].set(xlabel='Year', ylabel='Malaria prevalence, SAC (%)', title='(a) National school-age malaria')
ax[0].legend(fontsize=7.5)
for i, rw in VB.iterrows():
    ax[1].plot([100*rw.R105_lo, 100*rw.R105_hi], [rw.alpha, rw.alpha], color=BLUE, lw=3, solid_capstyle='butt')
    ax[1].plot([100*rw.R63_lo, 100*rw.R63_hi], [rw.alpha + 0.04, rw.alpha + 0.04], color=AQUA, lw=3, solid_capstyle='butt')
ax[1].plot([], [], color=BLUE, lw=3, label='window 105 d'); ax[1].plot([], [], color=AQUA, lw=3, label='window 63 d (prepatency)')
ax[1].axvspan(15.5, 36.6, color=light(ORANGE, 0.2), lw=0, label='observed 95% CI')
ax[1].axvline(25.0, color=ORANGE, lw=1.2)
ax[1].set(xlabel='Hookworm reinfection by week 18 (%)', ylabel='Membership degree $\\alpha$', title='(b) Reinfection, Pemba')
ax[1].set_ylim(-0.08, 1.45); ax[1].legend(fontsize=7.5, loc='upper right', ncol=1)
fig.tight_layout(); fig.savefig(F + 'fig6_validation.pdf'); plt.close(fig)

# ---------- Fig 7: sensitivity ----------
SI = pd.read_csv(R + 'sensitivity_indices.csv'); names = open(R + 'sensitivity_names.txt').read().split()
PR = pd.read_csv(R + 'prcc.csv'); pn = open(R + 'prcc_names.txt').read().split()
lab = {'nuh': '$\\nu_h$', 'psi': '$\\psi$', 'a': '$a$', 'b': '$b$', 'cmax': '$c_{\\max}$', 'mv': '$m_v$', 'nuv': '$\\nu_v$', 'muv': '$\\mu_v$',
       'ga': '$\\gamma_a$', 'gs': '$\\gamma_s$', 'beta_w': '$\\beta_w$', 'pimax': '$\\pi_{\\max}$', 'muL': '$\\mu_L$',
       'gw0': '$\\gamma_{w0}$', 'CR': 'CR', 'phi': '$\\phi$', 'theta0': '$\\theta_0$', 'thetaM': '$\\theta_M$',
       'eta': '$\\eta$', 'zeta': '$\\zeta$'}
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.6))
y = np.arange(len(names)); h = 0.27
ax[0].barh(y - h, SI.S_RM, h, color=BLUE, label='$\\mathcal{R}_M$')
ax[0].barh(y, SI.S_RW, h, color=ORANGE, label='$\\mathcal{R}_W$')
ax[0].barh(y + h, SI.S_Phi, h, color=AQUA, label='$\\Phi$')
ax[0].set_yticks(y); ax[0].set_yticklabels([lab[n] for n in names]); ax[0].invert_yaxis()
ax[0].axvline(0, color=INK2, lw=0.8); ax[0].set(xlabel='Normalised sensitivity index', title='(a) Local indices')
ax[0].legend(loc='lower left')
y = np.arange(len(pn))
ax[1].barh(y - h/2, PR.PRCC_Pc, h, color=AQUA, label='co-infection prevalence')
ax[1].barh(y + h/2, PR.PRCC_inc, h, color=BLUE, label='malaria incidence')
ax[1].set_yticks(y); ax[1].set_yticklabels([lab[n] for n in pn]); ax[1].invert_yaxis()
ax[1].axvline(0, color=INK2, lw=0.8); ax[1].set(xlabel='PRCC', title='(b) Global (LHS, N=400)', xlim=(-1, 1))
ax[1].legend(loc='lower left', fontsize=7.5)
fig.tight_layout(); fig.savefig(F + 'fig7_sensitivity.pdf'); plt.close(fig)

# ---------- Fig 8: fuzzy scenario trajectories ----------
def env(a, s):
    return pd.read_csv(R + 'env_a%d_s%d.csv' % (a, s))
fig, ax = plt.subplots(2, 2, figsize=(7.4, 5.4))
cols = [('Pm', 100, 'Malaria prevalence (%)', '(a)'), ('Pw', 100, 'Hookworm prevalence (%)', '(b)'),
        ('Pc', 100, 'Co-infection prevalence (%)', '(c)'), ('inc', 1, 'Malaria infections /1000 PY', '(d)')]
show = [1, 4, 6]
for k, (v, sc, yl, tl) in enumerate(cols):
    a_ = ax.flat[k]
    for s in show:
        e0 = env(0, s); e5 = env(50, s); e1 = env(100, s)
        t = 2026 + e0.t/365
        a_.fill_between(t, sc*e0[v + '_lo'], sc*e0[v + '_hi'], color=light(SC[s-1], 0.12), lw=0)
        a_.fill_between(t, sc*e5[v + '_lo'], sc*e5[v + '_hi'], color=light(SC[s-1], 0.28), lw=0)
        a_.plot(t, sc*e1[v + '_lo'], color=SC[s-1], lw=1.5, label=SN[s-1])
    a_.set(xlabel='Year', ylabel=yl, title=tl)
LG = {1: 'B: baseline', 4: 'M: vector control',
      6: 'I2: vector control + community deworming + WASH'}
hs = [plt.Line2D([], [], color=SC[s-1], lw=2.2, label=LG[s]) for s in show]
fig.legend(handles=hs, loc='lower center', ncol=3, fontsize=8, bbox_to_anchor=(0.5, 0.0))
fig.tight_layout(rect=(0, 0.06, 1, 1)); fig.savefig(F + 'fig8_scenarios.pdf'); plt.close(fig)

# ---------- Fig 9: fuzzy 2030 outcomes ----------
O = pd.read_csv(R + 'scenario_samples.csv')
al = [0, 0.25, 0.5, 0.75, 1.0]
fig, ax = plt.subplots(1, 2, figsize=(7.6, 3.4), gridspec_kw={'width_ratios': [1.15, 1]})
for s in range(1, 7):
    for a in al:
        sub = O[(O.alpha == a) & (O.scen == s)]
        if len(sub) == 0: continue
        w = 0.08 + 0.25*(1 - a)
        ax[0].plot([sub.inc_red.min(), sub.inc_red.max()], [s, s], color=light(SC[s-1], 0.25 + 0.75*a), lw=3 + 9*a, solid_capstyle='butt')
        ax[1].plot([100*sub.MHI30.min(), 100*sub.MHI30.max()], [s, s], color=light(SC[s-1], 0.25 + 0.75*a), lw=3 + 9*a, solid_capstyle='butt')
    core_s = O[(O.alpha == 1) & (O.scen == s)]
    ax[0].plot(core_s.inc_red, [s], '|', color=INK, ms=14, mew=1.5)
    ax[1].plot(100*core_s.MHI30, [s], '|', color=INK, ms=14, mew=1.5)
ax[0].axvline(80, color=RED, lw=1, ls='--'); ax[0].text(78, 0.15, 'GTS-equivalent (80%)', ha='right', fontsize=7.5, color=RED)
ax[1].axvline(2, color=RED, lw=1, ls='--'); ax[1].text(2.2, 0.15, 'WHO target <2%', fontsize=7.5, color=RED)
for a_ in ax:
    a_.set_yticks(range(1, 7)); a_.set_yticklabels(SN, fontsize=7.5); a_.set_ylim(6.6, -0.2)
ax[1].set_yticklabels([])
ax[0].set(xlabel='Malaria incidence reduction,\n2030 vs 2026 (%)', title='(a) Malaria (GTS)')
ax[1].set(xlabel='Moderate/heavy-intensity hookworm\nprevalence, 2030 (%)', title='(b) STH morbidity (NTD road map)')
fig.tight_layout(); fig.savefig(F + 'fig9_targets.pdf'); plt.close(fig)

# ---------- Fig: bifurcation diagram and global convergence ----------
BD = pd.read_csv(R + 'bifurcation.csv'); GCv = pd.read_csv(R + 'global_convergence.csv'); GF = pd.read_csv(R + 'global_regimes.csv')
fig = plt.figure(figsize=(7.4, 5.8))
gs = fig.add_gridspec(2, 10, height_ratios=[1.0, 0.95], hspace=0.55, wspace=1.6)
a0 = fig.add_subplot(gs[0, 0:5])
a0.plot(BD.RM, 100*BD.Pm_noW, color=INK2, ls='--', lw=1.5, label='without hookworm ($E_M$)')
a0.plot(BD.RM, 100*BD.Pm_coinf, color=BLUE, lw=2, label='with hookworm (core)')
thr = float(np.interp(1.0, BD.RMW, BD.RM))
a0.axvspan(thr, 1, color=light(ORANGE, 0.35), lw=0)
a0.annotate('hookworm-mediated\npersistence ($\\mathcal{R}_M<1<\\mathcal{R}_M^W$)', xy=((thr+1)/2, 1.0), xytext=(1.45, 2.5),
            fontsize=7.5, color=ORANGE, arrowprops=dict(arrowstyle='->', color=ORANGE, lw=0.8))
a0.set(xlabel='$\\mathcal{R}_M$ (varying $m_v$)', ylabel='Malaria prevalence (%)', title='(a) Bifurcation diagram')
a0.legend(fontsize=7.5, loc='upper left')
a1 = fig.add_subplot(gs[0, 5:10])
a1.plot(BD.RM, BD.maxeig*1e3, color=BLUE)
a1.axhline(0, color=INK2, lw=0.8)
a1.set(xlabel='$\\mathcal{R}_M$', ylabel='max Re$(\\lambda)$ ($10^{-3}$ day$^{-1}$)', title='(b) Stability of the attractor')
titles = ['(c) $E_0$', '(d) $E_W$', '(e) $E_M$', '(f) $\\mathcal{R}_M<1<\\mathcal{R}_M^W$', '(g) $E^*$']
for r in range(1, 6):
    a = fig.add_subplot(gs[1, 2*(r-1):2*r])
    sub = GCv[GCv.regime == r]
    for n in sorted(sub.ic.unique()):
        t = sub[sub.ic == n]
        a.plot(100*t.Pw, 100*t.Pm, color=light(SC[(r-1) % 6], 0.55), lw=0.7)
        a.plot(100*t.Pw.iloc[0], 100*t.Pm.iloc[0], '.', color=light(SC[(r-1) % 6], 0.9), ms=3)
    g = GF[GF.regime == r].iloc[0]
    a.plot(100*g.Pw_eq, 100*g.Pm_eq, 'o', color=INK, ms=5, mec='white', zorder=5)
    a.set_title(titles[r-1], fontsize=8)
    a.tick_params(labelsize=6.5)
    if r == 1: a.set_ylabel('Malaria (%)', fontsize=7.5)
    a.set_xlabel('Hookworm (%)', fontsize=7)
fig.savefig(F + 'fig_bifurcation.pdf', bbox_inches='tight'); plt.close(fig)

# ---------- Fig: critical deworming coverage ----------
PC = pd.read_csv(R + 'critical_coverage_curve.csv'); PI = pd.read_csv(R + 'critical_coverage_impulsive.csv')
fig, ax = plt.subplots(1, 2, figsize=(7.4, 2.9))
for g, c in zip(HC, GC):
    ax[0].axvspan(g[0], g[1], color=light(c, 0.15), lw=0)
ia = PI.phic_imp_annual.where(PI.phic_imp_annual <= 1); isem = PI.phic_imp_semi.where(PI.phic_imp_semi <= 1)
pa = PC.phic_annual.where(PC.phic_annual <= 1); ps = PC.phic_semi.where(PC.phic_semi <= 1)
ax[0].plot(PI.eps, 100*ia, color=BLUE, label='annual (impulsive)')
ax[0].plot(PI.eps, 100*isem, color=ORANGE, label='semi-annual (impulsive)')
ax[0].plot(PC.eps, 100*pa, color=BLUE, ls='--', lw=1.0, label='averaged approximation')
ax[0].plot(PC.eps, 100*ps, color=ORANGE, ls='--', lw=1.0)
ax[0].axhline(75, color=RED, lw=0.9, ls='--'); ax[0].text(2600, 77, 'WHO 75% coverage', fontsize=7, color=RED)
ax[0].axhline(22.5, color=INK2, lw=0.8, ls=':'); ax[0].text(2600, 24.5, 'school-only max (SAC 30%)', fontsize=7, color=INK2)
ax[0].set(xlabel='Hookworm intensity $\\epsilon$ (epg)', ylabel='Critical community coverage $\\phi_c$ (%)', xlim=(0, 4500), ylim=(0, 105),
          title='(a) Coverage needed to interrupt hookworm')
ax[0].legend(fontsize=7, loc='center right')
al = np.linspace(0, 1, 401); g = HG[0]
lo = g[0] + al*(g[1]-g[0]); hi = g[2] - al*(g[2]-g[1])
for col, c, lab_ in [('phic_imp_annual', BLUE, 'annual'), ('phic_imp_semi', ORANGE, 'semi-annual')]:
    fl = np.interp(lo, PI.eps, PI[col]); fh = np.interp(hi, PI.eps, PI[col])
    x = np.concatenate([100*np.minimum(fl, 1.05), 100*np.minimum(fh, 1.05)[::-1]]); y = np.concatenate([al, al[::-1]])
    ax[1].fill(x, y, color=light(c, 0.25), lw=0); ax[1].plot(x, y, color=c, label=lab_)
ax[1].axvline(75, color=RED, lw=0.9, ls='--')
ax[1].set(xlabel='Critical coverage $\\phi_c$ (%) [>100%: unattainable]', ylabel='Membership degree $\\alpha$', xlim=(0, 106),
          title='(b) Fuzzy $\\phi_c$, light-intensity group')
ax[1].legend(fontsize=7.5, loc='upper left')
fig.tight_layout(); fig.savefig(F + 'fig_coverage.pdf'); plt.close(fig)
print('figures written')
