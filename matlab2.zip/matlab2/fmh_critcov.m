function phic = fmh_critcov(p, d, T)
%FMH_CRITCOV Critical effective community deworming coverage phi_c that brings
%   R_W to one with rounds every T days (Corollary 3): tau_c = R_W(tau=0)(gw0+mu) - gw0 - mu,
%   phi_c = (1 - exp(-tau_c*T))/CR. Returns 0 if hookworm cannot persist without
%   treatment and Inf if phi_c > 1 (elimination unattainable by deworming alone).
q = p; q.phi = 0; dd = d; dd.gw = p.gw0;
[~, RW0] = fmh_R0(q, dd);
tauc = (RW0 - 1)*(p.gw0 + p.mu);
if tauc <= 0, phic = 0; return; end
phic = (1 - exp(-tauc*T))/p.CR;
if phic > 1, phic = Inf; end
end
