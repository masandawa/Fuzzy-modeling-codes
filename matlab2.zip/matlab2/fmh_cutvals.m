function V = fmh_cutvals(EQ, I)
%FMH_CUTVALS Extension principle on a sampled curve: [min max] of columns 2-4 of EQ over
%   the alpha-cut I = [lo hi] of the input variable (column 1), with interpolated end points.
x = EQ(:,1); j = x > I(1) & x < I(2);
V = zeros(1, 6);
for c = 2:4
    v = [interp1(x, EQ(:,c), I(1)); EQ(j,c); interp1(x, EQ(:,c), I(2))];
    V(2*c-3:2*c-2) = [min(v), max(v)];
end
end
