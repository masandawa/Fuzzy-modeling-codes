function P = fmh_hindcast_at(q, y0, umax, years, tq)
%FMH_HINDCAST_AT Hindcast prevalence evaluated at times tq (days after mid-2015).
[tt, Pm] = fmh_hindcast(q, y0, umax, years);
P = interp1(tt, Pm, tq);
end
