function fmh_writecsv(fname, header, M)
%FMH_WRITECSV Write numeric matrix M with a comma-separated header line.
fid = fopen(fname, 'w');
fprintf(fid, '%s\n', header);
fmt = [repmat('%.10g,', 1, size(M,2)-1) '%.10g\n'];
fprintf(fid, fmt, M');
fclose(fid);
end
