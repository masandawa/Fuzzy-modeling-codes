function [phic, rhoM] = fmh_critcov_imp(p, d, T)
%FMH_CRITCOV_IMP Critical coverage of IMPULSIVE deworming (rounds every T days, each
%   curing a fraction phi*CR of carriers). The linearised hookworm subsystem at the
%   origin, x' = A x between rounds and x -> D x at each round, has monodromy matrix
%   M(phi) = D(phi)*expm(A*T); hookworm is eliminated iff its spectral radius < 1.
%   phic solves rho(M(phi)) = 1 (0 if not needed; Inf if phi > 1 would be required).
kap = (1 - p.wash)*d.pi/p.muL;
A = [-(p.gw0 + p.mu), p.beta_w; p.muL*kap, -p.muL];
rhoM = @(phi) max(abs(eig(diag([1 - phi*p.CR, 1])*expm(A*T))));
if rhoM(0) <= 1, phic = 0; return; end
if rhoM(1) > 1,  phic = Inf; return; end
phic = fzero(@(f) rhoM(f) - 1, [0 1]);
end
