function I = fmh_alphacut(abc, alpha)
%FMH_ALPHACUT alpha-cut [lower upper] of a triangular fuzzy number (a,b,c).
I = [abc(1) + alpha*(abc(2) - abc(1)), abc(3) - alpha*(abc(3) - abc(2))];
end
