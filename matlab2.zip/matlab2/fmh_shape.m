function [pih, th, ch, gm] = fmh_shape(p, eps, rho)
%FMH_SHAPE Intensity-dependent (fuzzy) parameter functions.
%   pih(eps): normalised egg contamination, th(eps): malaria susceptibility modifier,
%   ch(rho): normalised infectiousness to mosquitoes, gm(rho): malaria clearance rate.
%   p.shape_eps / p.shape_rho select the response form ('linear' default; 'concave', 'sigmoid' for the
%   structural sensitivity analysis), see fmh_resp.m.
ke = 'linear'; kr = 'linear';
if isfield(p, 'shape_eps'), ke = p.shape_eps; end
if isfield(p, 'shape_rho'), kr = p.shape_rho; end
pih = fmh_resp((eps - p.eps_d)./(p.eps_M - p.eps_d), ke);
th  = p.theta0 + (p.thetaM - p.theta0).*fmh_resp(eps./p.eps_M, ke);
ch  = fmh_resp((rho - p.rho_min)./(p.rho_c - p.rho_min), kr);
gm  = p.ga + (p.gs - p.ga).*fmh_resp((rho - p.rho_min)./(p.rho_M - p.rho_min), kr);
end
